"""Deterministic code: extract values, derive scores, flag abnormalities, normalise drug names, apply rules.json."""
import difflib, json, operator, re
from pathlib import Path

RULES_PATH = Path(__file__).parent / "rules.json"
OPS = {"<": operator.lt, "<=": operator.le, ">": operator.gt, ">=": operator.ge}

PATTERNS = {
    "age": r"(\d{1,3})\s*[- ]?\s*years?\s*[- ]?old",
    "hr": r"\b(?:hr|heart rate|pulse)\s*[:=]?\s*(\d{2,3})\b",
    "rr": r"\b(?:rr|resp(?:iratory)? rate)\s*[:=]?\s*(\d{1,2})\b",
    "spo2": r"\bspo2\s*[:=]?\s*(\d{2,3})",
    "temp": r"\btemp(?:erature)?\s*[:=]?\s*(\d{2}(?:\.\d)?)",
    "hb": r"\b(?:hb|hgb|hemoglobin|haemoglobin)\s*[:=]?\s*(\d+(?:\.\d+)?)",
    "wbc": r"\b(?:tlc|wbc|wcc)\s*[:=]?\s*([\d,]+(?:\.\d+)?)",
    "platelets": r"\b(?:plt|platelets?)\s*[:=]?\s*([\d,]+(?:\.\d+)?)",
    "creatinine": r"\b(?:srcr|s\.?\s?cr|creatinine)\s*[:=]?\s*(\d+(?:\.\d+)?)",
    "potassium": r"\b(?:k|potassium)\s*[:=]\s*(\d+(?:\.\d+)?)",
    "magnesium": r"\b(?:mg|magnesium)\s*[:=]\s*(\d+(?:\.\d+)?)",
    "calcium": r"\b(?:ca|calcium)\s*[:=]\s*(\d+(?:\.\d+)?)",
    "albumin": r"\balbumin\s*[:=]?\s*(\d+(?:\.\d+)?)",
    "alt": r"\balt\s*[:=]?\s*(\d+)",
    "ast": r"\bast\s*[:=]?\s*(\d+)",
    "bilirubin": r"\b(?:t\.?\s?bil(?:irubin)?|total bilirubin)\s*[:=]?\s*(\d+(?:\.\d+)?)",
}
MENTATION = r"\b(dcl|depressed (?:level of )?consciousness|altered (?:mental|consciousness)|confus\w*|drows\w*|unresponsive)\b"
ASSUMPTIONS = ("Units assumed: creatinine, calcium, magnesium and bilirubin in mg/dL; potassium in mmol/L; "
               "haemoglobin and albumin in g/dL; WBC and platelets per µL (shown ×10³/µL); temperature in °C.")

CLASSES = {
    "acei_arb": "valsartan losartan candesartan irbesartan telmisartan olmesartan lisinopril enalapril ramipril perindopril captopril".split(),
    "beta_blocker": "bisoprolol metoprolol atenolol carvedilol nebivolol propranolol".split(),
    "antiplatelet": "aspirin clopidogrel ticagrelor prasugrel".split(),
    "nsaid": "ibuprofen diclofenac naproxen ketorolac celecoxib indomethacin".split(),
    "diuretic": "furosemide torsemide bumetanide hydrochlorothiazide indapamide spironolactone".split(),
}
GENERIC_CLASS = {g: c for c, gs in CLASSES.items() for g in gs}
BRANDS = {"concor": "bisoprolol", "tareg": "valsartan", "diovan": "valsartan", "cozaar": "losartan",
          "zestril": "lisinopril", "tenormin": "atenolol", "lopressor": "metoprolol", "coreg": "carvedilol",
          "plavix": "clopidogrel", "brilinta": "ticagrelor", "effient": "prasugrel", "lasix": "furosemide",
          "aldactone": "spironolactone", "voltaren": "diclofenac", "brufen": "ibuprofen"}
NAMES = {**{g: g for g in GENERIC_CLASS}, **BRANDS}


def _num(s): return float(s.replace(",", ""))


def extract_values(text):
    v = {}
    m = re.search(r"\b(?:blood pressure|bp)\s*[:=]?\s*(\d{2,3})\s*/\s*(\d{2,3})", text, re.I)
    if m: v["sbp"], v["dbp"] = float(m[1]), float(m[2])
    for k, pat in PATTERNS.items():
        m = re.search(pat, text, re.I)
        if m: v[k] = _num(m[1])
    for k in ("wbc", "platelets"):
        if k in v and v[k] >= 1000: v[k] /= 1000
    m = re.search(r"\b(female|woman|male|man)\b", text, re.I)
    if m: v["sex"] = "F" if m[1].lower() in ("female", "woman") else "M"
    m = re.search(MENTATION, text, re.I)
    v["altered_mentation"] = bool(m)
    v["mentation_term"] = m[1] if m else None
    return v


def derive(v):
    d = {}
    if "sbp" in v and "dbp" in v: d["map"] = round((v["sbp"] + 2 * v["dbp"]) / 3, 1)
    if "hr" in v and "sbp" in v: d["shock_index"] = round(v["hr"] / v["sbp"], 2)
    if "calcium" in v and "albumin" in v: d["corrected_ca"] = round(v["calcium"] + 0.8 * (4.0 - v["albumin"]), 1)
    if "rr" in v or "sbp" in v:
        d["qsofa"] = sum([v.get("rr", 0) >= 22, "sbp" in v and v["sbp"] <= 100, bool(v.get("altered_mentation"))])
    return d


def flag_list(v, d):
    out = []
    def add(i, label, value, note=""): out.append({"id": i, "label": label, "value": value, "note": note})
    g = v.get
    if "sbp" in v and (v["sbp"] < 90 or d.get("map", 999) < 65):
        add("hypotension", "Hypotension", f"BP {v['sbp']:g}/{v.get('dbp', 0):g}, MAP {d.get('map', '?')}")
    if g("temp", 0) >= 38.0: add("fever", "Fever", f"{v['temp']:g} °C")
    if g("hr", 0) > 100: add("tachycardia", "Tachycardia", f"HR {v['hr']:g}")
    if g("rr", 0) >= 22: add("tachypnea", "Tachypnoea", f"RR {v['rr']:g}")
    if "spo2" in v and v["spo2"] < 90: add("hypoxemia", "Hypoxaemia", f"SpO₂ {v['spo2']:g} %")
    if g("wbc", 0) > 12: add("leukocytosis", "Leukocytosis", f"{v['wbc']:g} ×10³/µL")
    if "hb" in v and v["hb"] < (13 if g("sex") == "M" else 12): add("anemia", "Anaemia", f"Hb {v['hb']:g} g/dL")
    if "platelets" in v:
        p = v["platelets"]
        if p < 50: add("thrombocytopenia_severe", "Severe thrombocytopenia", f"{p:g} ×10³/µL")
        elif p < 100: add("thrombocytopenia_moderate", "Moderate thrombocytopenia", f"{p:g} ×10³/µL")
        elif p < 150: add("thrombocytopenia_mild", "Mild thrombocytopenia", f"{p:g} ×10³/µL")
    if g("creatinine", 0) >= 1.5: add("aki_possible", "Raised creatinine (possible AKI)", f"{v['creatinine']:g} mg/dL", "baseline unknown")
    if "potassium" in v and v["potassium"] < 3.5: add("hypokalemia", "Hypokalaemia", f"K {v['potassium']:g} mmol/L")
    if "magnesium" in v and v["magnesium"] < 1.7: add("magnesium_low", "Low magnesium", f"Mg {v['magnesium']:g} mg/dL")
    if "albumin" in v and v["albumin"] < 3.5: add("hypoalbuminemia", "Hypoalbuminaemia", f"{v['albumin']:g} g/dL")
    if g("alt", 0) > 41: add("alt_raised", "Mildly raised ALT", f"{v['alt']:g} U/L")
    return out


def find_meds(text):
    found = {}
    for m in re.finditer(r"\b([A-Za-z][A-Za-z\-]{2,})\b", text):
        w = m[1].lower()
        if w in NAMES: found.setdefault(NAMES[w], {"input": m[1], "confidence": "exact"})
    for m in re.finditer(r"\b([A-Za-z][A-Za-z\-]{3,})\s+\d+(?:\.\d+)?\b", text):
        w = m[1].lower()
        if w in NAMES: continue
        close = difflib.get_close_matches(w, list(NAMES), n=1, cutoff=0.8)
        if close: found.setdefault(NAMES[close[0]], {"input": m[1], "confidence": "fuzzy"})
    return [{"generic": g, "class": GENERIC_CLASS[g], **info} for g, info in found.items()]


def load_rules(): return json.loads(RULES_PATH.read_text(encoding="utf-8"))


def _met(cond, ctx):
    return cond["field"] in ctx and OPS[cond["op"]](ctx[cond["field"]], cond["value"])


def evaluate_rules(v, d, meds, rules=None):
    ctx = {**v, **d}
    med_flags, case_flags = [], []
    for r in (rules or load_rules())["rules"]:
        reasons = [f"{c['field']} {ctx[c['field']]:g} {c['op']} {c['value']:g}" for c in r["applies_when"]["any"] if _met(c, ctx)]
        if not reasons: continue
        base = {k: r[k] for k in ("id", "title", "level", "message", "caveat", "sources")} | {"reasons": reasons}
        if r.get("case_level"): case_flags.append(base)
        else:
            drugs = [m for m in meds if m["class"] in r["drug_classes"]]
            if drugs: med_flags.append(base | {"drugs": drugs})
    return med_flags, case_flags


def patient_summary(v, d):
    parts = []
    if "age" in v: parts.append(f"{v['age']:g}-year-old" + (" woman" if v.get("sex") == "F" else " man" if v.get("sex") == "M" else ""))
    if "sbp" in v: parts.append(f"BP {v['sbp']:g}/{v.get('dbp', 0):g} (MAP {d.get('map', '?')})")
    for k, lab in (("hr", "HR"), ("rr", "RR"), ("spo2", "SpO2"), ("temp", "T")):
        if k in v: parts.append(f"{lab} {v[k]:g}")
    for k, lab in (("hb", "Hb"), ("wbc", "WBC"), ("platelets", "platelets"), ("creatinine", "creatinine"), ("potassium", "K")):
        if k in v: parts.append(f"{lab} {v[k]:g}")
    return "; ".join(parts) or "not given"


def analyze_facts(text):
    v = extract_values(text); d = derive(v); meds = find_meds(text)
    mf, cf = evaluate_rules(v, d, meds)
    return {"values": v, "derived": d, "flags": flag_list(v, d), "meds": meds, "med_flags": mf, "case_flags": cf,
            "assumptions": [ASSUMPTIONS], "summary": patient_summary(v, d)}
