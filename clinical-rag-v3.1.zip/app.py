"""Chat server: structured, verified guideline answers. Calls the Colab /retrieve and /generate endpoints."""
import asyncio, hmac, json, os
from pathlib import Path

from fastapi import FastAPI, Header, HTTPException
from fastapi.responses import FileResponse, StreamingResponse
from pydantic import BaseModel, Field

import pipeline

BASE = Path(__file__).parent
cfg = {"retrieve_url": os.getenv("COLAB_RETRIEVE_URL", "").strip(),   # base URL; "/retrieve" is appended
       "generate_url": os.getenv("COLAB_GENERATE_URL", "").strip()}   # full URL ending in "/generate"
MONGODB_URI = os.getenv("MONGODB_URI", "")
ACCESS_TOKEN = os.getenv("ACCESS_TOKEN", "")     # optional: protects /api/analyze
ADMIN_TOKEN = os.getenv("ADMIN_TOKEN", "")       # required to change the Colab URLs at runtime
MAX_PROBLEMS = int(os.getenv("MAX_PROBLEMS", "8"))
TIMEOUT = float(os.getenv("COLAB_TIMEOUT", "120"))

app = FastAPI(title="Clinical guideline RAG")
gpu_lock = asyncio.Semaphore(1)   # one analysis at a time, so requests do not time out each other
_tasks: set = set()


def _same(a, b): return a is not None and hmac.compare_digest(a.encode(), b.encode())


class AnalyzeIn(BaseModel):
    message: str = Field(min_length=1, max_length=8000)


class UrlsIn(BaseModel):
    retrieve_url: str | None = None
    generate_url: str | None = None


@app.post("/api/analyze")
async def analyze(body: AnalyzeIn, x_access_token: str | None = Header(None)):
    if ACCESS_TOKEN and not _same(x_access_token, ACCESS_TOKEN):
        raise HTTPException(401, "Invalid access token.")
    if not (cfg["retrieve_url"] and cfg["generate_url"] and MONGODB_URI):
        raise HTTPException(503, "Backend is not configured yet.")
    q: asyncio.Queue = asyncio.Queue()

    async def emit(text): await q.put({"type": "status", "text": text})

    async def work():
        try:
            if gpu_lock.locked(): await emit("Waiting for another request to finish")
            async with gpu_lock:
                backend = pipeline.Backend(cfg["retrieve_url"], cfg["generate_url"], MONGODB_URI, TIMEOUT)
                await q.put({"type": "result", "data": await pipeline.analyze(body.message, backend, emit, MAX_PROBLEMS)})
        except pipeline.BackendError as e:
            await q.put({"type": "error", "detail": str(e)})
        except Exception:
            await q.put({"type": "error", "detail": "Unexpected server error."})
        finally:
            await q.put(None)

    t = asyncio.create_task(work()); _tasks.add(t); t.add_done_callback(_tasks.discard)

    async def stream():
        while True:
            try: ev = await asyncio.wait_for(q.get(), 15)
            except asyncio.TimeoutError:
                yield '{"type":"ping"}\n'; continue   # keeps the tunnel connection alive
            if ev is None: break
            yield json.dumps(ev) + "\n"

    return StreamingResponse(stream(), media_type="application/x-ndjson",
                             headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})


@app.post("/api/admin/urls")
async def set_urls(body: UrlsIn, x_admin_token: str | None = Header(None)):
    if not ADMIN_TOKEN or not _same(x_admin_token, ADMIN_TOKEN): raise HTTPException(403, "Forbidden.")
    for key in ("retrieve_url", "generate_url"):
        v = getattr(body, key)
        if v is not None:
            if not v.startswith(("https://", "http://127.0.0.1", "http://localhost")):
                raise HTTPException(400, f"{key} must start with https://")
            cfg[key] = v.strip()
    return {"ok": True}


@app.get("/api/health")
async def health():
    return {"ok": True, "configured": bool(cfg["retrieve_url"] and cfg["generate_url"] and MONGODB_URI)}


@app.get("/")
async def index(): return FileResponse(BASE / "static" / "index.html")
