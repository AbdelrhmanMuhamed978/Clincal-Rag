import json
from pathlib import Path
import facts

CASE = json.loads((Path(__file__).parent / "cases" / "icu_septic_shock_pneumonia_01.json").read_text())["input"]


def test_values_and_derived():
    r = facts.analyze_facts(CASE)
    v, d = r["values"], r["derived"]
    assert (v["sbp"], v["dbp"], v["hr"], v["rr"], v["spo2"]) == (80, 50, 110, 30, 85)
    assert v["wbc"] == 22 and v["platelets"] == 25 and v["creatinine"] == 2.5 and v["potassium"] == 3
    assert d["map"] == 60.0 and d["corrected_ca"] == 9.9 and d["qsofa"] == 3


def test_flags_do_not_repeat_the_old_mistakes():
    ids = {f["id"] for f in facts.analyze_facts(CASE)["flags"]}
    assert {"hypokalemia", "thrombocytopenia_severe", "aki_possible", "hypoalbuminemia"} <= ids
    assert "ast_raised" not in ids


def test_brand_names_map_to_generics():
    meds = {m["generic"]: m for m in facts.analyze_facts(CASE)["meds"]}
    assert meds["bisoprolol"]["class"] == "beta_blocker"
    assert meds["valsartan"]["confidence"] == "fuzzy"      # "Targ 80"
    assert meds["clopidogrel"]["class"] == "antiplatelet" and "aspirin" in meds


def test_rules_fire_only_when_conditions_and_drugs_match():
    r = facts.analyze_facts(CASE)
    ids = {f["id"] for f in r["med_flags"]}
    assert ids == {"acei_arb_hypotension", "beta_blocker_review", "antiplatelet_low_platelets"}
    assert [f["id"] for f in r["case_flags"]] == ["vte_prophylaxis_low_platelets"]
    stable = facts.analyze_facts("blood pressure: 130/80, platelet: 250,000, srcr: 0.9, on concor 5 mg and plavix 75 mg")
    assert stable["med_flags"] == [] and stable["case_flags"] == []


def test_every_rule_has_a_source():
    for r in facts.load_rules()["rules"]:
        assert r["sources"] and all(s["url"].startswith("https://") for s in r["sources"])
