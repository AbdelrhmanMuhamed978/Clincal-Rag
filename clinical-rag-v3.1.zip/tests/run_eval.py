"""Scorecard for one or more cases.

  python tests/run_eval.py                 # offline: deterministic checks against a mock backend
  python tests/run_eval.py --real          # real Colab backend (env: COLAB_RETRIEVE_URL, COLAB_GENERATE_URL, MONGODB_URI)

Deterministic checks (values, flags, drug classes, rules) must pass in both modes.
Accuracy metrics (plan coverage, retrieval hits, verified vs rejected claims) are only meaningful with --real.
"""
import argparse, asyncio, json, os, re, sys, time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.path.insert(0, str(Path(__file__).resolve().parent))
import facts, pipeline


def check(rows, name, ok, detail=""):
    rows.append((ok, name, detail))


def deterministic(case, rows):
    ex, fx = case["expect"], facts.analyze_facts(case["input"])
    v, d = fx["values"], fx["derived"]
    for k, want in ex["values"].items(): check(rows, f"value {k}", v.get(k) == want, f"got {v.get(k)}, want {want}")
    for k, (lo, hi) in ex["derived"].items(): check(rows, f"derived {k}", k in d and lo <= d[k] <= hi, f"got {d.get(k)}, want {lo}..{hi}")
    ids = {f["id"] for f in fx["flags"]}
    for i in ex["flags_include"]: check(rows, f"flag {i}", i in ids)
    for i in ex.get("flags_exclude", []): check(rows, f"no flag {i}", i not in ids)
    meds = {m["generic"]: m["class"] for m in fx["meds"]}
    for g, c in ex["meds"].items(): check(rows, f"drug {g} -> {c}", meds.get(g) == c, f"got {meds.get(g)}")
    mf = {f["id"] for f in fx["med_flags"]}
    for i in ex["med_flags_include"]: check(rows, f"rule {i}", i in mf)
    for i in ex.get("med_flags_exclude", []): check(rows, f"no rule {i}", i not in mf)
    cf = {f["id"] for f in fx["case_flags"]}
    for i in ex["case_flags_include"]: check(rows, f"case rule {i}", i in cf)


def accuracy(case, res, rows, real, show):
    ex = case["expect"]
    titles = [p["title"] + " " + " ".join(p["queries"]) for p in res["problems"]]
    for alts in ex["topics_required"]:
        check(rows, f"plan covers {'/'.join(alts)}", any(re.search("|".join(alts), t, re.I) for t in titles))
    for m in ex.get("must_retrieve", []):
        hit = any(re.search(m["topic"], p["title"], re.I) and m["contains"].lower() in s["excerpt"].lower()
                  for p in res["problems"] for s in p["sources"])
        check(rows, f"retrieved '{m['contains']}' for {m['topic']}", hit)
    for bad in ex.get("forbidden_problems", []):
        check(rows, f"no invented problem '{bad}'", not any(bad in p["title"].lower() for p in res["problems"]))
    text = json.dumps(res).lower()
    for phrase in ex.get("forbidden_in_output", []): check(rows, f"output has no '{phrase}'", phrase.lower() not in text)
    ok = sum(len(p["items"]) for p in res["problems"]); rej = sum(len(p["unverified"]) for p in res["problems"])
    print(f"  verified claims: {ok} | rejected by checks: {rej} | problems not covered: {res['not_covered'] or 'none'}")
    for p in res["problems"]:
        top = max((s["score"] for s in p["sources"] if s.get("score") is not None), default=None)
        print(f"    - {p['title'][:48]:48} status={p['status']:10} chunks={len(p['sources'])} top_rerank={top if top is None else round(top, 2)}")
        for u in p["unverified"]: print(f"        rejected: {'; '.join(u['issues'])}")
        if show:
            for it in p["items"]:
                c = it["citation"]
                print(f"        OK  [{c['strength'] or 'no grade'}] {c['label']} p.{c['page']}{' (' + it['repaired'] + ')' if it.get('repaired') else ''}\n            {it['recommendation']}\n            quote: {it['quote']}")
            for u in p["unverified"]: print(f"        REJECTED claim: {u['recommendation']}\n            quote given: {u['quote']}")


async def run_case(path, real, show):
    case = json.loads(Path(path).read_text())
    rows = []
    deterministic(case, rows)
    if real:
        backend = pipeline.Backend(os.environ["COLAB_RETRIEVE_URL"], os.environ["COLAB_GENERATE_URL"], os.environ["MONGODB_URI"], 300)
    else:
        from mock_backend import MockBackend
        backend = MockBackend()
    t0, stages = time.time(), []
    async def emit(t): stages.append((round(time.time() - t0, 1), t))
    res = await pipeline.analyze(case["input"], backend, emit, int(os.getenv("MAX_PROBLEMS", "8")))
    print(f"\n== {case['id']}  ({'REAL backend' if real else 'mock backend, accuracy lines are not meaningful'})  {time.time() - t0:.1f}s")
    accuracy(case, res, rows, real, show)
    out = Path(__file__).parent / "out"; out.mkdir(exist_ok=True)
    (out / f"{case['id']}.json").write_text(json.dumps(res, indent=2, ensure_ascii=False))
    print(f"  full result saved to tests/out/{case['id']}.json")
    for s in stages: print(f"    [{s[0]:>6}s] {s[1]}")
    bad = [r for r in rows if not r[0]]
    for ok, name, detail in rows:
        if not ok: print(f"  FAIL {name} {detail}")
    print(f"  {len(rows) - len(bad)}/{len(rows)} checks passed")
    return not bad


if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--case"); ap.add_argument("--real", action="store_true"); ap.add_argument("--show", action="store_true")
    a = ap.parse_args()
    paths = [a.case] if a.case else sorted(str(p) for p in (Path(__file__).parent / "cases").glob("*.json"))
    ok = all([asyncio.run(run_case(p, a.real, a.show)) for p in paths])
    sys.exit(0 if ok else 1)
