import asyncio, json
from pathlib import Path
import pipeline
from mock_backend import MockBackend, plan

CASE = json.loads((Path(__file__).parent / "cases" / "icu_septic_shock_pneumonia_01.json").read_text())["input"]


async def _emit(_): pass


def run(text, backend, n=8): return asyncio.run(pipeline.analyze(text, backend, _emit, n))


def test_only_verified_items_are_shown():
    res = run("What MAP target is recommended in septic shock?", MockBackend())
    items = res["problems"][0]["items"]
    assert len(items) == 1 and items[0]["citation"]["draft"] is True
    reasons = [" ".join(u.get("issues", [])) for u in res["problems"][0]["unverified"]]
    assert any("quote not found" in r for r in reasons)           # invented sentence
    assert any("number(s) not in source: 75" in r for r in reasons)  # invented number
    assert any("not among the retrieved" in r for r in reasons)     # tag S9 does not exist
    assert any("DRAFT" in w for w in res["warnings"])


def test_not_found_is_reported_not_improvised():
    res = run("What is the stent plan?", MockBackend())
    assert res["problems"][0]["status"] == "not_found" and res["not_covered"] == ["Question"]


def test_planner_json_is_used_when_valid():
    b = MockBackend(plan(("Shock", "shock vasopressor"), ("Kidney", "kidney NAC")))
    res = run(CASE, b)
    assert res["plan_source"] == "llm+rules" and [p["title"] for p in res["problems"]][:2] == ["Shock", "Kidney"]
    assert res["problems"][1]["items"][0]["citation"]["strength"] == "2D"


def test_planner_falls_back_to_rules_when_llm_output_is_not_json():
    res = run(CASE, MockBackend())
    assert res["plan_source"] == "rules"
    titles = " ".join(p["title"].lower() for p in res["problems"])
    for topic in ("shock", "pneumonia", "ards", "thrombocytopenia", "kidney", "antiplatelet"):
        assert topic in titles


def test_case_result_carries_rule_flags_and_assumptions():
    res = run(CASE, MockBackend())
    assert res["facts"]["med_flags"] and any("Units assumed" in w for w in res["warnings"])
    assert any("Targ" in str(m) and m["confidence"] == "fuzzy" for m in res["facts"]["meds"])


def test_rule_detected_problems_are_added_when_the_llm_plan_omits_them():
    res = run(CASE, MockBackend(plan(("Shock", "shock vasopressor"))))
    titles = " ".join(p["title"].lower() for p in res["problems"])
    assert "thrombocytopenia" in titles and "kidney" in titles and "antiplatelet" in titles


def test_source_numbers_are_unique_and_ranked_by_score_when_chunks_are_structured():
    chunks = [{"society": "A", "year": 2020, "status": "final", "section": "s", "page": 1, "text": "low score text", "rerank_score": 0.2},
              {"society": "B", "year": 2021, "status": "draft", "section": "s", "page": 2, "text": "high score text", "rerank_score": 0.9},
              {"society": "B", "year": 2021, "status": "draft", "section": "s", "page": 2, "text": "high   score text", "rerank_score": 0.9}]
    src = pipeline.number_sources(pipeline.sources_from_chunks(chunks), 8)
    assert list(src) == ["S1", "S2"] and src["S1"]["label"] == "B 2021 (DRAFT)" and src["S1"]["draft"]
    assert list(pipeline.number_sources(pipeline.sources_from_chunks(chunks), 8, min_score=0.5)) == ["S1"]


def test_unsupported_reasoning_and_overstated_wording_are_rejected():
    s = pipeline.number_sources(pipeline.sources_from_text(
        "[S1] KDIGO 2012 (FINAL) | NAC | p.70 | 2D\n3.9.2: We suggest not using NAC to prevent AKI in critically ill patients with hypotension. (2D)"))
    bad = {"tag": "S1", "rec": "NAC is not recommended because evidence of efficacy is insufficient.", "quote": "We suggest not using NAC to prevent AKI"}
    assert any("not supported" in i for i in pipeline.verify_item(bad, s))
    strong = {"tag": "S1", "rec": "NAC should never be used to prevent AKI in critically ill patients.", "quote": "We suggest not using NAC to prevent AKI"}
    assert any("stronger" in i for i in pipeline.verify_item(strong, s))
    good = {"tag": "S1", "rec": "It is suggested not to use NAC to prevent AKI in critically ill patients with hypotension.", "quote": "We suggest not using NAC to prevent AKI"}
    assert pipeline.verify_item(good, s) == []


REAL_RUN_PLAN = plan(("Hypotension in Elderly", "hypotension vasopressor"), ("Fever in Elderly with Hypotension", "fever sepsis"),
                     ("Pneumonia in Elderly with Hypotension", "pneumonia antibiotics"), ("Acute Respiratory Distress Syndrome (ARDS)", "ards ventilation"),
                     ("Anemia in Critically Ill Elderly", "anemia transfusion"), ("Thrombocytopenia in Critically Ill Elderly", "platelets"),
                     ("Renal Dysfunction in Critically Ill Elderly", "kidney"), ("Heart Failure in Elderly with Hypotension", "heart failure"))


def test_plan_drops_invented_problems_and_never_cuts_rule_detected_ones():
    """Regression for the real run: the LLM filled all 8 slots, invented heart failure and left out antiplatelet management."""
    res = run(CASE, MockBackend(REAL_RUN_PLAN), 8)
    titles = [p["title"].lower() for p in res["problems"]]
    assert not any("heart failure" in t for t in titles)
    assert any("antiplatelet" in t for t in titles) and any("renal" in t or "kidney" in t for t in titles)
    assert any("hypokal" in t for t in titles) and len(titles) <= 8


def test_near_verbatim_quotes_are_repaired_to_the_real_source_text():
    s = pipeline.number_sources(pipeline.sources_from_text(
        "[S1] KDIGO 2026 (DRAFT) | Ch 3 | p.24 | 2C\nRecommendation 3.2.1: We suggest a mean arterial pressure (MAP) of >65 mm Hg as a target to guide fluid and vasopressor administration in critically ill adults at high risk of or with AKI (2C).\n"
        "[S2] KDIGO 2012 (FINAL) | NAC | p.70 | 2D\n3.9.2: We suggest not using NAC to prevent AKI in critically ill patients with hypotension. (2D)"))
    near = {"tag": "S1", "rec": "A MAP target above 65 mm Hg is suggested to guide fluids and vasopressors in critically ill adults at risk of AKI.",
            "quote": "a mean arterial pressure of >65 mm Hg as a target to guide fluid and vasopressor administration"}
    fixed = pipeline.repair_item(near, s)
    assert fixed["repaired"] == "quote corrected to the source text" and pipeline._norm(fixed["quote"]) in pipeline._norm(s["S1"]["text"])
    assert pipeline.verify_item(fixed, s) == []
    wrong_tag = {"tag": "S2", "rec": near["rec"], "quote": "mean arterial pressure (MAP) of >65 mm Hg as a target"}
    assert pipeline.repair_item(wrong_tag, s)["tag"] == "S1"
    invented = {"tag": "S1", "rec": "Use norepinephrine first.", "quote": "norepinephrine is the first choice vasopressor"}
    assert "repaired" not in pipeline.repair_item(invented, s) and pipeline.verify_item(pipeline.repair_item(invented, s), s)
