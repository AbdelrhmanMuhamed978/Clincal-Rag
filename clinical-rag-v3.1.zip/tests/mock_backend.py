"""Offline stand-in for the Colab server. Canned sources and answers, including deliberately bad ones."""
import json
import pipeline

CTX = {
 "shock": "[S1] KDIGO 2026 (DRAFT) | CHAPTER 3. PREVENTION AND TREATMENT OF AKI | p.24 | 2C\nRecommendation 3.2.1: We suggest a mean arterial pressure (MAP) of >65 mm Hg as a target to guide fluid and vasopressor administration in critically ill adults at high risk of or with AKI (2C).\n",
 "kidney": "[S1] KDIGO 2012 (FINAL) | N-ACETYLCYSTEINE (NAC) | p.70 | 2D\n3.9.2: We suggest not using NAC to prevent AKI in critically ill patients with hypotension. (2D)\n",
 "stent": "NOT_FOUND",
}
ANS = {
 "shock": ("SOURCE: S1\nRECOMMENDATION: A MAP target above 65 mm Hg is suggested to guide fluids and vasopressors in critically ill adults at risk of AKI.\nQUOTE: a mean arterial pressure (MAP) of >65 mm Hg as a target\n\n"
           "SOURCE: S1\nRECOMMENDATION: Vasopressors were superior to usual care.\nQUOTE: vasopressors and inotropes was superior to usual care\n\n"
           "SOURCE: S1\nRECOMMENDATION: Aim for a MAP of 75 mm Hg in all patients.\nQUOTE: mean arterial pressure (MAP) of >65 mm Hg\n\n"
           "SOURCE: S9\nRECOMMENDATION: Give norepinephrine first.\nQUOTE: norepinephrine first\n"),
 "kidney": "SOURCE: S1\nRECOMMENDATION: NAC is not suggested to prevent AKI in critically ill patients with hypotension (grade 2D).\nQUOTE: We suggest not using NAC to prevent AKI\n",
}


class MockBackend:
    def __init__(self, plan_json=None): self.plan_json, self.calls = plan_json, []

    def _key(self, text):
        t = text.lower()
        return next((k for k in ("shock", "kidney", "stent") if k in t), None)

    async def retrieve(self, query):
        self.calls.append(("retrieve", query))
        return {"context": CTX.get(self._key(query), "NOT_FOUND"), "chunks": None}

    async def generate(self, prompt, max_new_tokens=400):
        self.calls.append(("generate", prompt[:60]))
        if "Output ONLY JSON" in prompt:
            if self.plan_json is None: return "Sorry, I cannot do that."
            return self.plan_json
        src = prompt.split("Sources:", 1)[1]
        key = "shock" if "KDIGO 2026" in src else "kidney" if "N-ACETYLCYSTEINE" in src else None
        return ANS.get(key, "NOT_FOUND")


def plan(*pairs): return json.dumps({"problems": [{"title": t, "query": q} for t, q in pairs]})
