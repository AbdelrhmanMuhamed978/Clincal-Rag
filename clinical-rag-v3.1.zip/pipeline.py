"""Plan -> retrieve -> draft -> verify. Only planning and drafting use the LLM; every check is code."""
import asyncio, difflib, json, re
import httpx
import facts as F

DISCLAIMER = ("Decision support only. Not a substitute for clinical judgement. Medication flags come from a "
              "rule table compiled from public sources and are pending clinician review.")

PLAN_PROMPT = """You are helping a clinician search clinical practice guidelines.
Read the case and list the distinct clinical problems that need guideline-based management (at most {n}).
Rules:
- Use syndromes or diagnoses (for example "septic shock", "ARDS", "acute kidney injury", "thrombocytopenia"), not single symptoms.
- Include only problems that the case text or its numbers support. Never add a condition the case does not mention.
- Include antiplatelet or anticoagulant management when the patient takes such drugs and has a bleeding risk.
- Titles are short and contain no age words.
- For each problem give a search query (8 to 20 words) written for a guideline database: no patient identifiers, include the key patient factors.
Output ONLY JSON in this form and nothing else:
{{"problems":[{{"title":"...","query":"..."}}]}}

Case:
{case}
"""

ANSWER_PROMPT = """You are a clinical guideline assistant. Use ONLY the numbered sources below. Do not use outside knowledge and do not give patient-specific orders.
Problem: {problem}
Patient context: {patient}

Sources:
{context}

List up to 3 recommendations from the sources that directly address the problem. Stay close to the source wording: keep "suggest" as suggest and "recommend" as recommend, and copy numbers, doses and units exactly.
Use exactly this format for each item, with a blank line between items:
SOURCE: S<number>
RECOMMENDATION: one sentence
QUOTE: words copied exactly from that source, at most 15 words
If the sources do not directly address the problem, output exactly: NOT_FOUND

Format example (invented content, for format only):
SOURCE: S1
RECOMMENDATION: Drug X is recommended for condition Y.
QUOTE: we recommend drug X for condition Y
"""


class BackendError(Exception):
    pass


class Backend:
    """Talks to the Colab server (/retrieve and /generate)."""
    def __init__(self, retrieve_url, generate_url, mongodb_uri, timeout=120.0):
        self.retrieve_url, self.generate_url, self.mongodb_uri, self.timeout = retrieve_url, generate_url, mongodb_uri, timeout

    async def _post(self, url, payload, what):
        for attempt in range(2):
            try:
                async with httpx.AsyncClient(timeout=self.timeout) as c:
                    r = await c.post(url, json=payload)
                    r.raise_for_status()
                    return r.json()
            except httpx.TimeoutException:
                raise BackendError(f"The {what} step timed out. Check that the Colab notebook is still running.")
            except (httpx.HTTPError, ValueError) as e:
                if attempt == 0:
                    await asyncio.sleep(1.5); continue
                raise BackendError(f"The {what} step failed ({type(e).__name__}). The Colab server may be down or the URL changed.")

    async def retrieve(self, query):
        d = await self._post(self.retrieve_url.rstrip("/") + "/retrieve",
                             {"prompt": query, "mongodb_uri": self.mongodb_uri}, "retrieval")
        return {"context": d.get("context", "NOT_FOUND"), "chunks": d.get("chunks")}

    async def generate(self, prompt, max_new_tokens=400):
        d = await self._post(self.generate_url, {"prompt": prompt, "max_new_tokens": max_new_tokens,
                                                 "repetition_penalty": 1.0}, "generation")
        r = d.get("response") or ""
        if r.startswith("COLAB SERVER ERROR"):
            raise BackendError("The Colab server reported an error during generation.")
        return r


# ---------- sources ----------
def _norm(s):
    s = s.lower()
    s = re.sub(r"[\u2010-\u2015]", "-", s)
    s = re.sub(r"[\"'\u2018\u2019\u201c\u201d`*]", "", s)
    s = re.sub(r"(?<=\d),(?=\d)", "", s)
    return re.sub(r"\s+", " ", s).strip(" .…")


def sources_from_text(context):
    """Parse the '[S1] label | section | p.N | strength' text format into source dicts (no ids yet)."""
    out = []
    for part in re.split(r"(?m)^(?=\[S\d+\] )", context or ""):
        m = re.match(r"\[S\d+\]\s*([^\n]*)\n?(.*)", part, re.S)
        if not m: continue
        segs = [s.strip() for s in m[1].split("|")]
        page, strength = "", ""
        for s in segs[2:]:
            if s.lower().startswith("p."): page = s[2:].strip()
            elif s: strength = s
        out.append({"label": segs[0], "section": segs[1] if len(segs) > 1 else "", "page": page,
                    "strength": strength, "draft": "DRAFT" in segs[0].upper(), "text": m[2].strip(), "score": None})
    return out


def sources_from_chunks(chunks):
    out = []
    for c in chunks:
        draft = str(c.get("status", "")).lower() == "draft"
        label = f"{c.get('society', '')} {c.get('year', '')}".strip() + (" (DRAFT)" if draft else " (FINAL)")
        out.append({"label": label, "section": c.get("section") or "General", "page": str(c.get("page", "")),
                    "strength": c.get("strength") or "", "draft": draft, "text": (c.get("text") or "").strip(),
                    "score": c.get("rerank_score")})
    return out


def number_sources(srcs, max_n=8, min_score=0.0):
    """Dedupe, rank by reranker score when available, cut, and assign S1..Sk (unique within one problem)."""
    seen, uniq = set(), []
    for s in srcs:
        k = _norm(s["text"])[:200]
        if k and k not in seen:
            seen.add(k); uniq.append(s)
    if uniq and all(s.get("score") is not None for s in uniq):
        uniq.sort(key=lambda s: s["score"], reverse=True)
        if min_score: uniq = [s for s in uniq if s["score"] >= min_score]
    return {f"S{i}": s | {"id": f"S{i}"} for i, s in enumerate(uniq[:max_n], 1)}


def _interleave(lists):
    out = []
    for i in range(max((len(l) for l in lists), default=0)):
        out += [l[i] for l in lists if i < len(l)]
    return out


def context_text(sources):
    return "\n".join(f"[{s['id']}] {s['label']} | {s['section']} | p.{s['page']}" + (f" | {s['strength']}" if s["strength"] else "")
                     + f"\n{s['text']}\n" for s in sources.values())


def _cite(s): return {k: s[k] for k in ("id", "label", "section", "page", "strength", "draft")}


# ---------- parsing and verification ----------
def parse_items(text):
    items = []
    for block in re.split(r"(?im)^\s*SOURCE\s*:\s*", text or "")[1:]:
        tag = re.match(r"\[?\s*S?(\d+)", block)
        rec = re.search(r"(?is)RECOMMENDATION\s*:\s*(.*?)(?:\n\s*QUOTE\s*:|\Z)", block)
        quote = re.search(r"(?is)QUOTE\s*:\s*(.*)", block)
        if tag and rec:
            items.append({"tag": f"S{tag[1]}", "rec": rec[1].strip(), "quote": (quote[1] if quote else "").strip().strip("\"“”")})
    return items


STOP = set("the and for with that this which should would could into over under than then also not can may are was were been being from have has had their there these those such only about between during after before".split())
SOFT = re.compile(r"\b(suggest\w*|weak|conditional|consider\w*|may|could)\b|\b2[A-D]\b", re.I)
STRONG = re.compile(r"\b(must|should|strongly|always|mandatory)\b", re.I)


def support_ratio(rec, text):
    words = [w for w in re.findall(r"[a-z]{4,}", rec.lower()) if w not in STOP]
    if not words: return 1.0
    stems = {w[:5] for w in re.findall(r"[a-z]{4,}", text.lower())}
    return sum(w[:5] in stems for w in words) / len(words)


def verify_item(item, sources):
    src = sources.get(item["tag"])
    if not src: return ["cited source is not among the retrieved sources"]
    text, issues = _norm(src["text"]), []
    frags = [f for f in re.split(r"\.\.\.|…", item["quote"]) if _norm(f)]
    if not frags or any(_norm(f) not in text for f in frags): issues.append("quote not found in the cited source")
    missing = [n for n in re.findall(r"\d+(?:\.\d+)?", _norm(item["rec"]))
               if not re.search(rf"(?<![\d.]){re.escape(n)}(?!\d)", text)]
    if missing: issues.append("number(s) not in source: " + ", ".join(missing))
    if support_ratio(item["rec"], src["text"]) < 0.5: issues.append("recommendation wording is not supported by the source text")
    if STRONG.search(item["rec"]) and SOFT.search(src["strength"] + " " + item["quote"]):
        issues.append("wording is stronger than the source")
    return issues


def _best_span(quote, text):
    """Best-matching run of words in text for a near-verbatim quote: (ratio, original-case span)."""
    qn, words = _norm(quote), text.split()
    n, best = len(quote.split()), (0.0, "")
    sm = difflib.SequenceMatcher(None, autojunk=False); sm.set_seq2(qn)
    for size in range(max(3, n - 2), n + 3):
        for i in range(0, max(0, len(words) - size) + 1):
            span = " ".join(words[i:i + size]); sm.set_seq1(_norm(span))
            if sm.real_quick_ratio() > best[0] and sm.quick_ratio() > best[0]:
                r = sm.ratio()
                if r > best[0]: best = (r, span)
    return best


def repair_item(item, sources, threshold=0.88):
    """Never trust the model's quote: keep it if verbatim, move it to the source that really contains it, or replace it
    with the real source text when it is a near match. Otherwise leave it alone (it will be rejected)."""
    q = item["quote"]
    if not q.strip() or re.search(r"\.\.\.|…", q): return item
    src = sources.get(item["tag"])
    if src and _norm(q) in _norm(src["text"]): return item
    for s_ in sources.values():
        if _norm(q) in _norm(s_["text"]): return item | {"tag": s_["id"], "repaired": "citation corrected"}
    best = max((( _best_span(q, s_["text"]), s_) for s_ in ([src] if src else sources.values())), key=lambda x: x[0][0], default=None)
    if best and best[0][0] >= threshold and best[0][1]:
        return item | {"tag": best[1]["id"], "quote": best[0][1], "repaired": "quote corrected to the source text"}
    return item


# ---------- planning ----------
FAMILIES = {"shock": r"shock|hypotens|vasopress|\bmap\b", "pneumonia": r"pneumon", "ards": r"\bards\b|ventilat|hypox|respiratory (?:failure|distress)",
            "antiplatelet": r"antiplatelet|antithrombotic|anticoag|stent|\bdapt\b|clopidogrel",   # before "platelets": "antiplatelet" contains "platelet"
            "platelets": r"thrombocytopen|platelet", "aki": r"kidney|\baki\b|renal", "anemia": r"an(a)?emia|transfusion",
            "electrolytes": r"hypokal|potassium|magnesium"}
EVIDENCE = {
    "shock": lambda i, t: "hypotension" in i or "shock" in t,
    "pneumonia": lambda i, t: bool(re.search(r"pneumon|consolidation|infiltrat", t)),
    "ards": lambda i, t: "hypoxemia" in i or bool(re.search(r"\bards\b|hypox|desaturat", t)),
    "platelets": lambda i, t: any(x.startswith("thrombocytopenia") for x in i) or "platelet" in t,
    "aki": lambda i, t: "aki_possible" in i or bool(re.search(r"kidney|\baki\b|renal|creatinine", t)),
    "anemia": lambda i, t: "anemia" in i,
    "electrolytes": lambda i, t: "hypokalemia" in i or "magnesium_low" in i or bool(re.search(r"potassium|hypokal|magnes", t)),
    "antiplatelet": lambda i, t: bool(re.search(r"stent|antiplatelet|clopidogrel|plavix|dapt|ticagrelor|aspirin|anticoag|warfarin", t)),
}
GENERIC = {"elder", "patie", "criti", "adult", "manag", "treat", "thera", "acute", "sever", "chron", "syndr", "disea", "injur"}


def _family(s):
    return next((k for k, p in FAMILIES.items() if re.search(p, s.lower())), None)


def _primary(title):
    return re.split(r"\b(?:in|with|due to|and|of|during)\b", title, maxsplit=1, flags=re.I)[0]


def _stems(s): return {w[:5] for w in re.findall(r"[a-z]{4,}", s.lower())}


def _grounded(p, text, ids):
    """Keep a planner problem only if the case supports it (rule evidence for known problem types, else shared wording)."""
    prim = _primary(p["title"]); fam = _family(prim)
    if fam: return bool(EVIDENCE[fam](ids, text.lower()))
    return bool((_stems(prim) - GENERIC) & _stems(text))


def rule_problems(text, flags):
    ids, t, P = {f["id"] for f in flags}, text.lower(), []
    low_plt = any(i.startswith("thrombocytopenia") for i in ids)
    def add(title, query): P.append({"title": title, "query": query})
    if "hypotension" in ids or "shock" in t: add("Septic shock and hypotension", "vasopressor and fluid management, MAP target in septic shock in critically ill adults")
    if re.search(r"pneumonia|consolidation|infiltrat", t): add("Pneumonia", "antibiotic treatment of severe community-acquired pneumonia in ICU adults")
    if re.search(r"\bards\b|hypox|desaturat", t) or "hypoxemia" in ids: add("ARDS and hypoxaemic respiratory failure", "lung-protective mechanical ventilation tidal volume ARDS oxygenation target")
    if low_plt: add("Thrombocytopenia", "thrombocytopenia platelet transfusion threshold bleeding risk in critically ill adults")
    if "aki_possible" in ids: add("Acute kidney injury", "management of acute kidney injury in sepsis fluids nephrotoxins renal replacement therapy")
    if "anemia" in ids: add("Anaemia", "red blood cell transfusion threshold in critically ill adults with ischemic heart disease")
    if "hypokalemia" in ids or "magnesium_low" in ids: add("Hypokalaemia and low magnesium", "potassium and magnesium replacement for hypokalemia in cardiac patients")
    if low_plt and re.search(r"stent|antiplatelet|plavix|clopidogrel|dapt", t): add("Antiplatelet therapy with a recent stent", "dual antiplatelet therapy after stent bleeding risk thrombocytopenia")
    return P


def fallback_plan(text, flags):
    return rule_problems(text, flags) or [{"title": "Case question", "query": text[:300]}]


async def make_plan(text, flags, backend, n):
    """LLM plan, filtered to problems the case supports; rule-detected problems are always kept (they are never cut by the cap)."""
    ids, llm = {f["id"] for f in flags}, []
    try:
        raw = await backend.generate(PLAN_PROMPT.format(n=n, case=text), 500)
        data = json.loads(raw[raw.index("{"): raw.rindex("}") + 1])
        llm = [{"title": str(p["title"])[:80], "query": str(p["query"])[:300]} for p in data["problems"] if p.get("title") and p.get("query")]
    except BackendError:
        raise
    except Exception:
        pass
    ok, seen = [], set()
    for p in llm:
        if not _grounded(p, text, ids): continue
        fam = _family(_primary(p["title"]))
        if fam and fam in seen: continue
        if fam: seen.add(fam)
        ok.append(p)
    ok.sort(key=lambda p: _family(_primary(p["title"])) is None)      # symptom-only items go last, so they are cut first
    extra = [p for p in rule_problems(text, flags) if _family(_primary(p["title"])) not in seen]
    plan = (ok[:max(0, n - len(extra))] + extra)[:max(n, len(extra))]
    return plan or fallback_plan(text, flags), ("llm+rules" if llm else "rules")


# ---------- one problem ----------
async def retrieve_problem(p, backend, n_queries, max_chunks, min_score):
    queries = [p["query"], f"{p['title']} recommendation"][:n_queries]
    rets = await asyncio.gather(*[backend.retrieve(q) for q in queries])
    lists, errors = [], 0
    for r in rets:
        ctx = r["context"]
        if ctx.startswith("ERROR"): errors += 1; continue
        lists.append(sources_from_chunks(r["chunks"]) if r.get("chunks") else sources_from_text(ctx))
    sources = number_sources(_interleave(lists), max_chunks, min_score)
    return {"queries": queries, "sources": sources, "errored": errors == len(rets)}


async def answer_problem(p, ret, backend, patient):
    sources = ret["sources"]
    res = {"title": p["title"], "queries": ret["queries"], "status": "not_found", "items": [], "unverified": [],
           "sources": [_cite(s) | {"excerpt": s["text"][:400], "score": s["score"]} for s in sources.values()]}
    if ret["errored"]: return res | {"status": "error", "detail": "Retrieval returned an error."}
    if not sources: return res
    out = await backend.generate(ANSWER_PROMPT.format(problem=p["title"], patient=patient, context=context_text(sources)), 500)
    items = parse_items(out)
    for it in items:
        it = repair_item(it, sources)
        issues = verify_item(it, sources)
        entry = {"recommendation": it["rec"], "quote": it["quote"]} | ({"repaired": it["repaired"]} if it.get("repaired") else {})
        if it["tag"] in sources: entry["citation"] = _cite(sources[it["tag"]])
        (res["unverified"] if issues else res["items"]).append(entry | ({"issues": issues} if issues else {}))
    res["status"] = "ok" if res["items"] else ("unverified" if items else "not_found")
    return res


# ---------- whole request ----------
async def analyze(text, backend, emit, max_problems=8, queries_per_problem=2, max_chunks=8, min_score=0.0):
    case_mode = len(text.split()) >= 40
    fx = None
    if case_mode:
        await emit("Reading values and medications")
        fx = F.analyze_facts(text)
    flags = fx["flags"] if fx else []
    patient = fx["summary"] if fx else "not given"
    if case_mode:
        await emit("Planning the guideline questions")
        plan, plan_source = await make_plan(text, flags, backend, max_problems)
    else:
        plan, plan_source = [{"title": "Question", "query": text}], "single_question"
    await emit(f"Retrieving guideline passages for {len(plan)} problem(s)")
    rets = await asyncio.gather(*[retrieve_problem(p, backend, queries_per_problem, max_chunks, min_score) for p in plan],
                                return_exceptions=True)
    failures = [r for r in rets if isinstance(r, Exception)]
    if len(failures) == len(rets): raise failures[0]
    problems = []
    for i, (p, ret) in enumerate(zip(plan, rets), 1):
        await emit(f"Drafting and checking answer {i} of {len(plan)}: {p['title']}")
        if isinstance(ret, Exception):
            problems.append({"title": p["title"], "queries": [], "status": "error", "detail": str(ret), "items": [], "unverified": [], "sources": []})
            continue
        try:
            problems.append(await answer_problem(p, ret, backend, patient))
        except BackendError as e:
            if i == 1: raise
            problems.append({"title": p["title"], "queries": ret["queries"], "status": "error", "detail": str(e), "items": [], "unverified": [], "sources": []})
    warnings = []
    if any(it.get("citation", {}).get("draft") for pr in problems for it in pr["items"]):
        warnings.append("Some citations come from DRAFT guidelines (marked DRAFT). Do not treat them as final.")
    if fx:
        warnings.append(fx["assumptions"][0])
        if fx["values"].get("mentation_term"):
            warnings.append(f"“{fx['values']['mentation_term']}” was read as altered consciousness (used for qSOFA).")
        if any(m["confidence"] == "fuzzy" for m in fx["meds"]):
            warnings.append("A drug name was matched approximately (marked “verify”). Confirm the actual drug.")
        if fx["values"].get("creatinine", 0) > 20:
            warnings.append("Creatinine looks like µmol/L, but mg/dL was assumed. Check the unit.")
    return {"plan_source": plan_source, "facts": fx, "problems": problems,
            "not_covered": [p["title"] for p in problems if p["status"] != "ok"],
            "warnings": warnings, "disclaimer": DISCLAIMER}
