"""Colab model server (port 8000). Your original server plus accuracy fixes. Run it inside the notebook; do NOT expose it publicly."""
import asyncio, collections, gc, math, sys, threading, time, traceback
import nest_asyncio, torch, uvicorn
from fastapi import FastAPI
from pydantic import BaseModel
from pymongo import MongoClient
from sentence_transformers import CrossEncoder, SentenceTransformer
from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig, pipeline

nest_asyncio.apply()
app = FastAPI()
DEV = "cuda" if torch.cuda.is_available() else "cpu"


class RequestModel(BaseModel):
    prompt: str
    mongodb_uri: str = None
    max_new_tokens: int = 512
    repetition_penalty: float = 1.0   # 1.0 = off. A penalty above 1 discourages copying text from the prompt (hurts verbatim quotes and numbers)
    top_k: int = 8


print(f"⏳ Loading PubMedBERT and BGE reranker on {DEV}...")
embedder = SentenceTransformer("pritamdeka/S-PubMedBert-MS-MARCO", device=DEV)
reranker = CrossEncoder("BAAI/bge-reranker-large", device=DEV, max_length=512)

MODEL = "Qwen/Qwen2.5-14B-Instruct"
print(f"⏳ Loading {MODEL} in 4-bit...")
bnb = BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_quant_type="nf4", bnb_4bit_compute_dtype=torch.float16, bnb_4bit_use_double_quant=True)
tokenizer = AutoTokenizer.from_pretrained(MODEL)
model = AutoModelForCausalLM.from_pretrained(MODEL, quantization_config=bnb, device_map="auto", torch_dtype=torch.float16, attn_implementation="sdpa")
llm = pipeline("text-generation", model=model, tokenizer=tokenizer)

_clients = {}


def collection(uri):
    if uri not in _clients: _clients[uri] = MongoClient(uri, serverSelectionTimeoutMS=15000)
    return _clients[uri]["Rag_Db"]["Guidlines_Embbdding"]


@app.post("/retrieve")
def retrieve(req: RequestModel):
    query, uri = req.prompt, req.mongodb_uri
    if not uri: return {"context": "ERROR: No MongoDB URI provided"}
    try:
        coll = collection(uri)
        q_vec = embedder.encode([query], normalize_embeddings=True)[0].tolist()
        vec = list(coll.aggregate([{"$vectorSearch": {"index": "vector_index", "path": "embedding", "queryVector": q_vec, "numCandidates": 200, "limit": 40}}]))
        txt = list(coll.aggregate([{"$search": {"index": "text_index", "compound": {"must": [{"text": {"query": query, "path": ["text", "section", "title"]}}]}}}, {"$limit": 40}]))
        scores, docs = collections.defaultdict(float), {}
        for lst in (vec, txt):
            for r, d in enumerate(lst):
                scores[d["chunk_id"]] += 1.0 / (60 + r + 1)
                docs.setdefault(d["chunk_id"], d)
        merged = [docs[i] for i, _ in sorted(scores.items(), key=lambda x: x[1], reverse=True)[:40]]
        if not merged: return {"context": "NOT_FOUND"}
        r_scores = reranker.predict([(query, (c.get("section", "") + "\n" + c["text"])) for c in merged])
        if min(r_scores) < 0 or max(r_scores) > 1: r_scores = [1 / (1 + math.exp(-x)) for x in r_scores]
        for c, s in zip(merged, r_scores): c["rerank_score"] = float(s)
        top = sorted(merged, key=lambda x: x["rerank_score"], reverse=True)[:max(1, min(req.top_k, 20))]
        parts, chunks = [], []
        for i, c in enumerate(top, 1):
            status = "DRAFT" if c.get("status") == "draft" else "FINAL"
            section = c.get("section", "General")
            strength = f" | {c['strength']}" if c.get("strength") else ""
            parts.append(f"[S{i}] {c.get('society', '')} {c.get('year', '')} ({status}) | {section} | p.{c.get('page', '')}{strength}\n{c['text']}\n")
            chunks.append({"chunk_id": c.get("chunk_id"), "society": c.get("society", ""), "year": c.get("year", ""), "status": c.get("status", ""),
                           "section": section, "page": c.get("page", ""), "strength": c.get("strength", ""), "text": c["text"],
                           "rerank_score": round(c["rerank_score"], 4)})
        return {"context": "\n".join(parts), "chunks": chunks}   # "context" keeps the old format; "chunks" adds scores
    except Exception as e:
        return {"context": f"ERROR: {e}"}


@app.post("/generate")
def generate_text(req: RequestModel):
    try:
        gc.collect(); torch.cuda.empty_cache()
        prompt = tokenizer.apply_chat_template([{"role": "user", "content": req.prompt}], tokenize=False, add_generation_prompt=True)
        with torch.inference_mode():
            out = llm(prompt, max_new_tokens=max(32, min(req.max_new_tokens, 1500)), do_sample=False, return_full_text=False,
                      repetition_penalty=req.repetition_penalty, eos_token_id=tokenizer.eos_token_id, pad_token_id=tokenizer.eos_token_id)
        return {"response": out[0]["generated_text"].strip()}
    except Exception:
        err = traceback.format_exc(); print("GENERATION ERROR:\n" + err)
        return {"response": f"COLAB SERVER ERROR:\n{err}"}


@app.get("/health")
def health(): return {"ok": True, "model": MODEL, "device": DEV}


def _serve():
    loop = asyncio.new_event_loop(); asyncio.set_event_loop(loop)
    loop.run_until_complete(uvicorn.Server(uvicorn.Config(app, host="127.0.0.1", port=8000, log_level="error", loop="asyncio")).serve())


threading.Thread(target=_serve, daemon=True).start()
time.sleep(3)
print("✅ Model server running on 127.0.0.1:8000 (local only)")
