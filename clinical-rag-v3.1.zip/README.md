---
title: Clinical Guideline Assistant
emoji: 🩺
colorFrom: blue
colorTo: indigo
sdk: docker
app_port: 7860
---

# Clinical guideline assistant (v3.1, accuracy first)

## How a question is answered
1. **Code** reads vitals, labs and drugs from the case (`facts.py`): MAP, shock index, albumin-corrected calcium, qSOFA, abnormal-value flags, brand to generic drug names (e.g. "Targ 80" is read as valsartan and marked "verify").
2. **Code** applies the sourced rule table (`rules.json`) to those values and drugs. No LLM is involved. Each rule lists its sources and caveat.
3. **Planner**: the LLM lists the problems; rule-detected problems the LLM missed are added, so none is silently dropped.
4. **Retrieval per problem** (2 queries, merged, reranker scores kept). Source numbers `S1…` are unique within one problem.
5. **Drafting per problem**: one short LLM call, format `SOURCE / RECOMMENDATION / QUOTE`.
6. **Verification (code only)**: the quote must appear verbatim in the cited source; every number must appear in the source; the wording must be supported by the source text and not stronger than it (suggest vs should). Anything else is rejected and shown separately. Grade, guideline name, page and DRAFT label come from the source header, never from the LLM.
7. Problems with no verified statement are listed as **not covered**.

## Files
`app.py` server (streams progress, needed because tunnels cut idle requests) · `pipeline.py` · `facts.py` · `rules.json` · `colab_server.py` (model server with scores and no repetition penalty) · `tests/` (unit tests, mock backend, `run_eval.py`).

## Colab
Open `clinical_rag_colab.ipynb` and run the cells in order. Only the chat page is tunnelled; the model server stays on localhost.

## Evaluate
`python tests/run_eval.py` (offline, deterministic checks) · `python tests/run_eval.py --real` (real backend: per-problem status, rejected claims, rerank scores, timings). Add one JSON file per case in `tests/cases/`.

## Settings
`MONGODB_URI`, `ACCESS_TOKEN` (protects the chat), `ADMIN_TOKEN` (change backend URLs at runtime), `COLAB_RETRIEVE_URL`, `COLAB_GENERATE_URL`, `COLAB_TIMEOUT`, `MAX_PROBLEMS` (default 8).

## Limits
Decision support only. The rule table was compiled from public sources by an AI assistant and must be approved by a clinician. Chat history is not used in this mode.
